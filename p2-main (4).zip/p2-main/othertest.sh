#!/usr/bin/env bash

for i in {1..8500}
do 
	echo -n "=This string is fourty characters long.=" >> mnt/otherout.txt

done

echo -e "\nmade large file" 
